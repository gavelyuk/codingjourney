git add .
git commit -am "m4sterbunny just updated  m4sterbunny/SkillingUp"
git push
hexo clean
hexo generate
hexo deploy